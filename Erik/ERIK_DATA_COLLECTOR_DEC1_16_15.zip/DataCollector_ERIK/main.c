//****************************************************************************
// 
//                          FALL DETECTOR V1.0
//                         THIS PROGRAM ONLY DOES
//                         DATA COLLECTION
//
// main.c - MSP-EXP432P401R + Educational Boosterpack MkII
//          
//          Accelerometer   X   P6.1    A14         ADC
//                          Y   P4.0    A13         ADC
//                          Z   P4.2    A11         ADC
// 
//****************************************************************************

#define TESTING_WITH_A
// or
// #define TESTING_WITH_A


#include <stdio.h>
#include <stdbool.h>
#include "msp.h"
#include <driverlib.h>
#include <grlib.h>
#include "Crystalfontz128x128_ST7735.h"
//#include <ESP8266.h>
#include <MSPIO.h>
#include <hardware_init.h>
#include <utils.h>
#include <uart_driver.h>
#include <set_accelerometer.h>
#include <data_collector.h>
#include <math.h>


void startUp();




#define X 0
#define Y 1
#define Z 2



//Globals
const uint32_t uart_baudrate = 115200;


// Graphic library context
Graphics_Context g_sContext;

// Timer_A Compare Configuration Parameter (PWM)
Timer_A_CompareModeConfig compareConfig_PWM = {
TIMER_A_CAPTURECOMPARE_REGISTER_4,          // Use CCR3
        TIMER_A_CAPTURECOMPARE_INTERRUPT_DISABLE,   // Disable CCR interrupt
        TIMER_A_OUTPUTMODE_TOGGLE_SET,              // Toggle output but
        5000                                    // 10% Duty Cycle initially
        };

// Timer_A Up Configuration Parameter
const Timer_A_UpModeConfig upConfig = {
TIMER_A_CLOCKSOURCE_SMCLK,                      // SMCLK = 3 MhZ
        TIMER_A_CLOCKSOURCE_DIVIDER_3,         // SMCLK/3 = 1000 KhZ
        10000,                                  // .. ms tick period
        TIMER_A_TAIE_INTERRUPT_DISABLE,         // Disable Timer interrupt
        TIMER_A_CCIE_CCR0_INTERRUPT_DISABLE,    // Disable CCR0 interrupt
        TIMER_A_DO_CLEAR                        // Clear value
        };
//****************************************************************************
//                              Main function
int main(void)
{
    //char msg[50];
    _hwInit();
    _realTimeClockInit();
    _graphicsInit();
    startUp();

    _ADCInit();
    uart_init(uart_baudrate);
    collect();

    while(1)
    {   
        displayRealTimeClock();

    }
}
//****************************************************************************


void startUp()
{
    Graphics_clearDisplay(&g_sContext);
    draw("FALL DETECTOR", 64, 50);
    draw("v1.0", 64, 64);
    
    delayWithCountDown(5000000, 64, 80);

    Graphics_clearDisplay(&g_sContext);
}


