/* --COPYRIGHT--,BSD
 * Copyright (c) 2015, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//****************************************************************************
//
// main.c - MSP-EXP432P401R + Educational Boosterpack MkII - Accelerometer
//
//          Displays raw 14-bit ADC measurements for X, Y, and Z axis
//          on the colored LCD.
//
//          Tilting the boosterpack to the 4 different vertical orientations
//          also controls the LCD orientation accordingly.
//
//****************************************************************************

#include "msp.h"
#include <driverlib.h>
#include <grlib.h>
#include "Crystalfontz128x128_ST7735.h"
#include <stdio.h>

#define X 0
#define Y 1
#define Z 2
#define GDELAY 250
#define LENGTHFALL 150

Timer_A_CompareModeConfig compareConfig_PWM = {
TIMER_A_CAPTURECOMPARE_REGISTER_4,          // Use CCR3
        TIMER_A_CAPTURECOMPARE_INTERRUPT_DISABLE,   // Disable CCR interrupt
        TIMER_A_OUTPUTMODE_TOGGLE_SET,              // Toggle output but
        5000                                    // 10% Duty Cycle initially
        };

/* Timer_A Up Configuration Parameter */
const Timer_A_UpModeConfig upConfig = {
TIMER_A_CLOCKSOURCE_SMCLK,                      // SMCLK = 3 MhZ
        TIMER_A_CLOCKSOURCE_DIVIDER_12,         // SMCLK/12 = 250 KhZ
        20000,                                  // 40 ms tick period
        TIMER_A_TAIE_INTERRUPT_DISABLE,         // Disable Timer interrupt
        TIMER_A_CCIE_CCR0_INTERRUPT_DISABLE,    // Disable CCR0 interrupt
        TIMER_A_DO_CLEAR                        // Clear value
        };

/* Graphic library context */
Graphics_Context g_sContext;



/* ADC results buffer */
static uint16_t resultsBuffer[3];
int delay;

void drawTitle(void);
void drawAccelData(void);
void drawStartUp();
int fallDetection();
void drawFallAlert();
void initDisplay();
void initSettings();
void initClock();
void pinConf();
void ADCConf();
void drawAskForHelpAlert();




/*
 * Main function
 */
void main(void)
{
    initSettings();
    initClock();
    initDisplay();
    pinConf();
    ADCConf();


    while(1)
    {
        MAP_PCM_gotoLPM0();
    }
}


void initDisplay(){
    /* Initializes display */
    Crystalfontz128x128_Init();

    /* Set default screen orientation */
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP);

    /* Initializes graphics context */
    Graphics_initContext(&g_sContext, &g_sCrystalfontz128x128);
    Graphics_setForegroundColor(&g_sContext, GRAPHICS_COLOR_WHITE);
    Graphics_setBackgroundColor(&g_sContext, GRAPHICS_COLOR_BLACK);
    GrContextFontSet(&g_sContext, &g_sFontFixed6x8);
    drawStartUp();
}

void initSettings(){
    /* Halting WDT and disabling master interrupts */
        MAP_WDT_A_holdTimer();
        MAP_Interrupt_disableMaster();

        /* Set the core voltage level to VCORE1 */
        MAP_PCM_setCoreVoltageLevel(PCM_VCORE1);

        /* Set 2 flash wait states for Flash bank 0 and 1*/
        MAP_FlashCtl_setWaitState(FLASH_BANK0, 2);
        MAP_FlashCtl_setWaitState(FLASH_BANK1, 2);
}

void initClock(){
    /* Initializes Clock System */
        MAP_CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_48);
        MAP_CS_initClockSignal(CS_MCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1 );
        MAP_CS_initClockSignal(CS_HSMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1 );
        MAP_CS_initClockSignal(CS_SMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1 );
        MAP_CS_initClockSignal(CS_ACLK, CS_REFOCLK_SELECT, CS_CLOCK_DIVIDER_1);
}

void pinConf(){
    /* Configures Pin 4.0, 4.2, and 6.1 as ADC input and 2.7(buzzer) */
       MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4, GPIO_PIN0 | GPIO_PIN2, GPIO_TERTIARY_MODULE_FUNCTION);
       MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P6, GPIO_PIN1, GPIO_TERTIARY_MODULE_FUNCTION);
       GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P2, GPIO_PIN7,
           GPIO_PRIMARY_MODULE_FUNCTION);





}

void ADCConf(){
    /* Initializing ADC (ADCOSC/64/8) */
      MAP_ADC14_enableModule();
      MAP_ADC14_initModule(ADC_CLOCKSOURCE_ADCOSC, ADC_PREDIVIDER_64, ADC_DIVIDER_8,
              0);

      /* Configuring ADC Memory (ADC_MEM0 - ADC_MEM2 (A11, A13, A14)  with no repeat)
           * with internal 2.5v reference */
      MAP_ADC14_configureMultiSequenceMode(ADC_MEM0, ADC_MEM2, true);
      MAP_ADC14_configureConversionMemory(ADC_MEM0,
              ADC_VREFPOS_AVCC_VREFNEG_VSS,
              ADC_INPUT_A14, ADC_NONDIFFERENTIAL_INPUTS);

      MAP_ADC14_configureConversionMemory(ADC_MEM1,
              ADC_VREFPOS_AVCC_VREFNEG_VSS,
              ADC_INPUT_A13, ADC_NONDIFFERENTIAL_INPUTS);

      MAP_ADC14_configureConversionMemory(ADC_MEM2,
              ADC_VREFPOS_AVCC_VREFNEG_VSS,
              ADC_INPUT_A11, ADC_NONDIFFERENTIAL_INPUTS);

      /* Enabling the interrupt when a conversion on channel 2 (end of sequence)
       *  is complete and enabling conversions */
      MAP_ADC14_enableInterrupt(ADC_INT2);

      /* Enabling Interrupts */
      MAP_Interrupt_enableInterrupt(INT_ADC14);
      MAP_Interrupt_enableMaster();

      /* Setting up the sample timer to automatically step through the sequence
       * convert.
       */
      MAP_ADC14_enableSampleTimer(ADC_AUTOMATIC_ITERATION);

      /* Triggering the start of the sample */
      MAP_ADC14_enableConversion();
      MAP_ADC14_toggleConversionTrigger();
}



/*
 * Clear display and redraw title + accelerometer data
 */

void drawStartUp(){
    Graphics_clearDisplay(&g_sContext);
    Graphics_drawStringCentered(&g_sContext,
                                       "FALL",
                                       AUTO_STRING_LENGTH,
                                       64,
                                       30,
                                       OPAQUE_TEXT);
    Graphics_drawStringCentered(&g_sContext,
                                           "DETECTOR",
                                           AUTO_STRING_LENGTH,
                                           64,
                                           70,
                                           OPAQUE_TEXT);

    for(delay=10000000; delay>0; delay--);

    drawTitle();
}

void drawTitle()
{
    Graphics_clearDisplay(&g_sContext);


    Graphics_drawStringCentered(&g_sContext,
                                    "Accelerometer:",
                                    AUTO_STRING_LENGTH,
                                    64,
                                    30,
                                    OPAQUE_TEXT);
    drawAccelData();
}


/*
 * Redraw accelerometer data
 */
void drawAccelData()
{
    char string[8];

    sprintf(string, "X: %5d", resultsBuffer[X]);
    Graphics_drawStringCentered(&g_sContext,
                                    (int8_t *)string,
                                    8,
                                    64,
                                    50,
                                    OPAQUE_TEXT);

    sprintf(string, "Y: %5d", resultsBuffer[Y]);
    Graphics_drawStringCentered(&g_sContext,
                                    (int8_t *)string,
                                    8,
                                    64,
                                    70,
                                    OPAQUE_TEXT);

    sprintf(string, "Z: %5d", resultsBuffer[Z]);
    Graphics_drawStringCentered(&g_sContext,
                                    (int8_t *)string,
                                    8,
                                    64,
                                    90,
                                    OPAQUE_TEXT);

}


/* This interrupt is fired whenever a conversion is completed and placed in
 * ADC_MEM2. This signals the end of conversion and the results array is
 * grabbed and placed in resultsBuffer */
void ADC14_IRQHandler(void)
{
    uint64_t status;

    status = MAP_ADC14_getEnabledInterruptStatus();
    MAP_ADC14_clearInterruptFlag(status);

    /* ADC_MEM2 conversion completed */
    if(status & ADC_INT2)
    {
        if(fallDetection()==1){
                drawFallAlert();
        }

       /* /* Store ADC14 conversion results */
        resultsBuffer[X] = ADC14_getResult(ADC_MEM0);
        resultsBuffer[Y] = ADC14_getResult(ADC_MEM1);
        resultsBuffer[Z] = ADC14_getResult(ADC_MEM2);

        /*
         * Draw accelerometer data on display and determine if orientation
         * change thresholds are reached and redraw as necessary
         */
        if (resultsBuffer[X] < 4900) {
            if (Lcd_Orientation != LCD_ORIENTATION_LEFT) {
                Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_LEFT);
                drawTitle();
            }
            else
                drawAccelData();
        }
        else if (resultsBuffer[X] > 11300) {
            if (Lcd_Orientation != LCD_ORIENTATION_RIGHT){
                Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_RIGHT);
                drawTitle();
            }
            else
                drawAccelData();
        }
        else if (resultsBuffer[Y] < 5000) {
            if (Lcd_Orientation != LCD_ORIENTATION_UP){
                Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP);
                drawTitle();
            }
            else
                drawAccelData();
        }
        else if (resultsBuffer[Y] > 11300) {
            if (Lcd_Orientation != LCD_ORIENTATION_DOWN){
                Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_DOWN);
                drawTitle();
            }
            else
                drawAccelData();
        }
        else
            drawAccelData();
    }


}

int fallDetection(){

    int detect;
    detect=0;

    int startBuffer[3];
    int midBuffer[3];
    int endBuffer[3];

    startBuffer[X] = ADC14_getResult(ADC_MEM0);
    startBuffer[Y] = ADC14_getResult(ADC_MEM1);
    startBuffer[Z] = ADC14_getResult(ADC_MEM2);
    for(delay=GDELAY; delay>0; delay--);

    midBuffer[X] = ADC14_getResult(ADC_MEM0);
    midBuffer[Y] = ADC14_getResult(ADC_MEM1);
    midBuffer[Z] = ADC14_getResult(ADC_MEM2);
    for(delay=GDELAY; delay>0; delay--);

    endBuffer[X] = ADC14_getResult(ADC_MEM0);
    endBuffer[Y] = ADC14_getResult(ADC_MEM1);
    endBuffer[Z] = ADC14_getResult(ADC_MEM2);

    if(startBuffer[X]+LENGTHFALL<midBuffer[X] || midBuffer[X]+LENGTHFALL<endBuffer[X]){
        detect = 1;
    }
    if(startBuffer[Y]+LENGTHFALL<midBuffer[Y] || midBuffer[Y]+LENGTHFALL<endBuffer[Y]){
        detect = 1;
    }
    if(startBuffer[Z]+LENGTHFALL<midBuffer[Z] || midBuffer[Z]+LENGTHFALL<endBuffer[Z]){
        detect = 1;
    }

    return detect;
}

void drawFallAlert(){
    Graphics_clearDisplay(&g_sContext);
    /* Configuring Timer_A0 for Up Mode and starting */
              Timer_A_configureUpMode(TIMER_A0_BASE, &upConfig);
              Timer_A_startCounter(TIMER_A0_BASE, TIMER_A_UP_MODE);

              /* Initialize compare registers to generate PWM */
              Timer_A_initCompare(TIMER_A0_BASE, &compareConfig_PWM); // For P2.7

    Graphics_drawStringCentered(&g_sContext,
                                           "FALLING",
                                           AUTO_STRING_LENGTH,
                                           64,
                                           30,
                                           OPAQUE_TEXT);
        Graphics_drawStringCentered(&g_sContext,
                                               "DOWN",
                                               AUTO_STRING_LENGTH,
                                               64,
                                               70,
                                               OPAQUE_TEXT);

        for(delay=10000000; delay>0; delay--);

        Timer_A_stopTimer(TIMER_A0_BASE);

        drawAskForHelpAlert();
}

void drawAskForHelpAlert(){
    Graphics_clearDisplay(&g_sContext);
    Graphics_drawStringCentered(&g_sContext,
                                              "NEED HELP?",
                                              AUTO_STRING_LENGTH,
                                              64,
                                              30,
                                              OPAQUE_TEXT);
    Graphics_drawStringCentered(&g_sContext,
                                                  "PRESS A",
                                                  AUTO_STRING_LENGTH,
                                                  64,
                                                  50,
                                                  OPAQUE_TEXT);
    Graphics_drawStringCentered(&g_sContext,
                                                      "TO SEND MESSAGE",
                                                      AUTO_STRING_LENGTH,
                                                      64,
                                                      70,
                                                      OPAQUE_TEXT);

    for(delay=10000000; delay>0; delay--);
    drawTitle();
}


