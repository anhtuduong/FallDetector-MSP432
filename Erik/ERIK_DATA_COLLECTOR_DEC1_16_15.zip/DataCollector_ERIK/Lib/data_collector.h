/*
 * data_collector.h
 *
 *  Created on: Nov 30, 2021
 *      Author: Erik Nielsen
 */

#ifndef LIB_DATA_COLLECTOR_H_
#define LIB_DATA_COLLECTOR_H_

void collect();



#endif /* LIB_DATA_COLLECTOR_H_ */
