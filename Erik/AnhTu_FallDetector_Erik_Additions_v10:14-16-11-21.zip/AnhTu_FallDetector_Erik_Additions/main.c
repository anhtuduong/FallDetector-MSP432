//****************************************************************************
// 
//                          FALL DETECTOR V1.0            
//
// main.c - MSP-EXP432P401R + Educational Boosterpack MkII
//          
//          Accelerometer   P4.0 P4.2 P6.1      ADC
//          Buzzer          P2.7                PM_TA0.4    
//          Button S1       P5.1
//          Button S2       P3.5
//
//****************************************************************************
#include "msp.h"
#include <driverlib.h>
#include <grlib.h>
#include "Crystalfontz128x128_ST7735.h"
#include <stdio.h>


void _hwInit();
void _accelSensorInit();
void _graphicsInit();
void _accelSensorInit();
void _buzzerInit();
void _buttonInit();
void startUp();
void draw(char* text, int32_t x, int32_t y);
void drawAccelData();
void buzzerPlay();
void delay(int i);
int fallDetected();
void startFallAlert();


#define X 0
#define Y 1
#define Z 2
#define GDELAY 50
//#define LENGTHFALL 150

// Graphic library context
Graphics_Context g_sContext;

// Timer_A Compare Configuration Parameter (PWM)
Timer_A_CompareModeConfig compareConfig_PWM = {
TIMER_A_CAPTURECOMPARE_REGISTER_4,          // Use CCR3
        TIMER_A_CAPTURECOMPARE_INTERRUPT_DISABLE,   // Disable CCR interrupt
        TIMER_A_OUTPUTMODE_TOGGLE_SET,              // Toggle output but
        5000                                    // 10% Duty Cycle initially
        };

// Timer_A Up Configuration Parameter
const Timer_A_UpModeConfig upConfig = {
TIMER_A_CLOCKSOURCE_SMCLK,                      // SMCLK = 3 MhZ
        TIMER_A_CLOCKSOURCE_DIVIDER_12,         // SMCLK/12 = 250 KhZ
        20000,                                  // 40 ms tick period
        TIMER_A_TAIE_INTERRUPT_DISABLE,         // Disable Timer interrupt
        TIMER_A_CCIE_CCR0_INTERRUPT_DISABLE,    // Disable CCR0 interrupt
        TIMER_A_DO_CLEAR                        // Clear value
        };

// ADC results buffer
static uint16_t resultBuffer[3];

//****************************************************************************
//                              Main function
int main(void)
{
    _hwInit();
    _graphicsInit();
    _accelSensorInit();
    _buzzerInit();
    _buttonInit();

    while(1)
    {
        PCM_gotoLPM0();
    }
}
//****************************************************************************

// Draw text on screen
// 
void draw(char* text, int32_t x, int32_t y)
{
    Graphics_drawStringCentered(&g_sContext,
                                (int8_t *) text,
                                AUTO_STRING_LENGTH,
                                x,
                                y,
                                OPAQUE_TEXT);                           
}

void startUp()
{
    Graphics_clearDisplay(&g_sContext);
    draw("FALL DETECTOR", 64, 30);
    draw("v1.0", 64, 70);
    delay(10000000);
    drawTitle();
}

// Clear display and redraw title + accelerometer data
// 
void drawTitle()
{
    Graphics_clearDisplay(&g_sContext);
    draw("Accelerometer:", 64, 30);

    drawAccelData();
}

// Redraw accelerometer data
// 
void drawAccelData()
{
    char string[10];

    sprintf(string, "X: %5d", resultBuffer[X]);
    Graphics_drawStringCentered(&g_sContext, (int8_t *) string, 8, 64, 50,
    OPAQUE_TEXT);

    sprintf(string, "Y: %5d", resultBuffer[Y]);
    Graphics_drawStringCentered(&g_sContext, (int8_t *) string, 8, 64, 70,
    OPAQUE_TEXT);

    sprintf(string, "Z: %5d", resultBuffer[Z]);
    Graphics_drawStringCentered(&g_sContext, (int8_t *) string, 8, 64, 90,
    OPAQUE_TEXT);
}

void buzzerPlay()
{
    // Configuring Timer_A0 for Up Mode and starting
    Timer_A_configureUpMode(TIMER_A0_BASE, &upConfig);
    Timer_A_startCounter(TIMER_A0_BASE, TIMER_A_UP_MODE);

    // Initialize compare registers to generate PWM
    Timer_A_initCompare(TIMER_A0_BASE, &compareConfig_PWM); // For P2.7
}

void delay(int i)
{
    int k;
    for(k=i; k>0; k--);
}

int fallDetected()
{
    // long int x = resultBuffer[X];
    // long int y = resultBuffer[Y];
    // long int z = resultBuffer[Z];

    // float totalAcceleration = sqrt(x*x + y*y + z*z);

    // if(totalAcceleration < 100)
    // {
    //     return 1;
    // }
    // else
    // {
    //     return 0;
    // }

    int detect;
    detect=0;
    int meanWalk[3] = {542 ,523, 722} , devWalk[3] = {22 ,25, 17};
    int minValue[3], maxValue[3];
    int startBuffer[3];
    int midBuffer[3];
    int i;
    //int endBuffer[3];

    for(i = 0; i<3; i++){
        minValue[i] = meanWalk[i] - 3*devWalk[i];
        maxValue[i] = meanWalk[i] - 3*devWalk[i];
    }


    startBuffer[X] = ADC14_getResult(ADC_MEM0);
    startBuffer[Y] = ADC14_getResult(ADC_MEM1);
    startBuffer[Z] = ADC14_getResult(ADC_MEM2);
    delay(GDELAY);

    midBuffer[X] = ADC14_getResult(ADC_MEM0);
    midBuffer[Y] = ADC14_getResult(ADC_MEM1);
    midBuffer[Z] = ADC14_getResult(ADC_MEM2);

    for(i = 0; i<3; i++){
        if(startBuffer[i]< minValue[i] || startBuffer[i]> maxValue[i]){
                if(midBuffer[i]< minValue[i] || midBuffer[i]> maxValue[i]){
                    detect = 1;
                }
        }
    }


    return detect;
}

void startFallAlert()
{
    Interrupt_disableInterrupt(INT_ADC14);

    Graphics_clearDisplay(&g_sContext);
    draw("FALL DETECTED", 64, 30);
    draw("Press S1 if OK", 64, 70);
    draw("Press S2 to SOS", 64, 90);

    delay(50000000);
}

//****************************************************************************
//                  Initialize hardware + sensors
// 
void _hwInit()
{
    // Halting WDT and disabling master interrupts
    WDT_A_holdTimer();
    Interrupt_disableMaster();

    // Set the core voltage level to VCORE1
    PCM_setCoreVoltageLevel(PCM_VCORE1);

    // Set 2 flash wait states for Flash bank 0 and 1
    FlashCtl_setWaitState(FLASH_BANK0, 2);
    FlashCtl_setWaitState(FLASH_BANK1, 2);

    // Initializes Clock System
    CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_48);
    CS_initClockSignal(CS_MCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);
    CS_initClockSignal(CS_HSMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);
    CS_initClockSignal(CS_SMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);
    CS_initClockSignal(CS_ACLK, CS_REFOCLK_SELECT, CS_CLOCK_DIVIDER_1);
}



void _accelSensorInit()
{
    // Pin 4.0, 4.2, 6.1 as ADC input
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4,
                                               GPIO_PIN0 | GPIO_PIN2,
                                               GPIO_TERTIARY_MODULE_FUNCTION);
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P6,
                                               GPIO_PIN1,
                                               GPIO_TERTIARY_MODULE_FUNCTION);

    // Initializing ADC (ADCOSC/64/8)
    ADC14_enableModule();
    ADC14_initModule(ADC_CLOCKSOURCE_ADCOSC, ADC_PREDIVIDER_64, ADC_DIVIDER_8, 0);

    // Configuring ADC Memory (ADC_MEM0 - ADC_MEM2 (A11, A13, A14)  with no repeat)
    // with internal 2.5v reference
    ADC14_configureMultiSequenceMode(ADC_MEM0, ADC_MEM2, true);
    ADC14_configureConversionMemory(ADC_MEM0,
    ADC_VREFPOS_AVCC_VREFNEG_VSS,
                                    ADC_INPUT_A14, ADC_NONDIFFERENTIAL_INPUTS);

    ADC14_configureConversionMemory(ADC_MEM1,
    ADC_VREFPOS_AVCC_VREFNEG_VSS,
                                    ADC_INPUT_A13, ADC_NONDIFFERENTIAL_INPUTS);

    ADC14_configureConversionMemory(ADC_MEM2,
    ADC_VREFPOS_AVCC_VREFNEG_VSS,
                                    ADC_INPUT_A11, ADC_NONDIFFERENTIAL_INPUTS);

    // Enabling the interrupt when a conversion on channel 2 (end of sequence)
    // is complete and enabling conversions
    ADC14_enableInterrupt(ADC_INT2);                  

    // Enabling Interrupts
    Interrupt_enableInterrupt(INT_ADC14);
    Interrupt_enableMaster();

    // Setting up the sample timer to automatically step through the sequence
    // convert
    ADC14_enableSampleTimer(ADC_AUTOMATIC_ITERATION);

    // Triggering the start of application
    ADC14_enableConversion();
    ADC14_toggleConversionTrigger();
}

void _graphicsInit()
{
    // Initializes display
    Crystalfontz128x128_Init();

    // Set default screen orientation
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP);

    // Initializes graphics context
    Graphics_initContext(&g_sContext, &g_sCrystalfontz128x128);
    Graphics_setForegroundColor(&g_sContext, GRAPHICS_COLOR_BLACK);
    Graphics_setBackgroundColor(&g_sContext, GRAPHICS_COLOR_WHITE);
    GrContextFontSet(&g_sContext, &g_sFontFixed6x8);

    startUp();
}

void _buzzerInit()
{
    // P2.7 to PM_TA0.4 for using Timer PWM to control LED
    GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P2,
                                                GPIO_PIN7,
                                                GPIO_TERTIARY_MODULE_FUNCTION);
}

void _buttonInit()
{
    // P5.1 as input for button S1
    GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P5, GPIO_PIN1);
    GPIO_enableInterrupt(GPIO_PORT_P5, GPIO_PIN1);

    // P3.5 as input for button S2
    GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P3, GPIO_PIN5);
    GPIO_enableInterrupt(GPIO_PORT_P3, GPIO_PIN5);

    // Enable interrupt
    Interrupt_enableInterrupt(INT_PORT5);
    Interrupt_enableInterrupt(INT_PORT3);
    Interrupt_enableMaster();
}

//****************************************************************************
//                          Interrupts 

// Get X, Y, Z from accelerometer
// 
void ADC14_IRQHandler(void)
{
    uint64_t status = MAP_ADC14_getEnabledInterruptStatus();

    MAP_ADC14_clearInterruptFlag(status);

    /* ADC_MEM2 conversion completed */
    if(status & ADC_INT2)
    {
        if(fallDetected() == 1){
            startFallAlert();
        }

       /* /* Store ADC14 conversion results */
        resultBuffer[X] = ADC14_getResult(ADC_MEM0);
        resultBuffer[Y] = ADC14_getResult(ADC_MEM1);
        resultBuffer[Z] = ADC14_getResult(ADC_MEM2);

        /*
         * Draw accelerometer data on display and determine if orientation
         * change thresholds are reached and redraw as necessary
         */
        if (resultBuffer[X] < 4900) {
            if (Lcd_Orientation != LCD_ORIENTATION_LEFT) {
                Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_LEFT);
                drawTitle();
            }
            else
                drawAccelData();
        }
        else if (resultBuffer[X] > 11300) {
            if (Lcd_Orientation != LCD_ORIENTATION_RIGHT){
                Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_RIGHT);
                drawTitle();
            }
            else
                drawAccelData();
        }
        else if (resultBuffer[Y] < 5000) {
            if (Lcd_Orientation != LCD_ORIENTATION_UP){
                Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP);
                drawTitle();
            }
            else
                drawAccelData();
        }
        else if (resultBuffer[Y] > 11300) {
            if (Lcd_Orientation != LCD_ORIENTATION_DOWN){
                Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_DOWN);
                drawTitle();
            }
            else
                drawAccelData();
        }
        else
            drawAccelData();
    }
}

// Button S1
// 
void PORT5_IRQHandler(void)
{
    uint_fast16_t status = GPIO_getEnabledInterruptStatus(GPIO_PORT_P5);

    GPIO_clearInterruptFlag(GPIO_PORT_P5, status);

    // Button S1 pressed
    if(status & GPIO_PIN1)
    {
        Graphics_clearDisplay(&g_sContext);
        draw("OK", 64, 30);
        delay(5000000);
        drawTitle();
        Interrupt_enableInterrupt(INT_ADC14);
        Interrupt_enableMaster();
    }
}

// Button S2
// 
void PORT3_IRQHandler(void)
{
    uint_fast16_t status = GPIO_getEnabledInterruptStatus(GPIO_PORT_P3);

    GPIO_clearInterruptFlag(GPIO_PORT_P3, status);

    // Button S2 pressed
    if(status & GPIO_PIN5)
    {
        Graphics_clearDisplay(&g_sContext);
        draw("SOS...", 64, 30);
        delay(5000000);
        drawTitle();
        Interrupt_enableInterrupt(INT_ADC14);
        Interrupt_enableMaster();
    }
}
